<#
  Exportiert alle Defender-XDR-Custom-Detections per Graph API in eine CSV
  für die Sentinel-Watchlist "CustomDetectionRules" (SearchKey: RuleId).

  Voraussetzung: Install-Module Microsoft.Graph.Authentication
  Recht:         CustomDetection.Read.All (delegiert)

  Die Spalten AnalyticsRuleName, ManualStatus und Notes pflegst du in der CSV.
  Bei erneutem Export bleiben sie erhalten (Abgleich über RuleId).
#>
param(
    [string]$Path = ".\CustomDetectionRules.csv"
)

Connect-MgGraph -Scopes "CustomDetection.Read.All" -NoWelcome

# Manuell gepflegte Spalten aus vorhandener CSV übernehmen
$manual = @{}
if (Test-Path $Path) {
    Import-Csv $Path | ForEach-Object { $manual[$_.RuleId] = $_ }
}

$rules = @()
$uri = "https://graph.microsoft.com/beta/security/rules/detectionRules"
while ($uri) {
    $resp  = Invoke-MgGraphRequest -Method GET -Uri $uri -OutputType PSObject
    $rules += $resp.value
    $uri   = $resp.'@odata.nextLink'
}

$rows = foreach ($r in $rules) {
    $tpl   = $r.detectionAction.alertTemplate
    $query = [string]$r.queryCondition.queryText
    # Verwendete Tabellen grob aus der Query ziehen (Zeilenanfang, union, join)
    $tables = [regex]::Matches($query, '(?m)^\s*(?:let\s+\w+\s*=\s*)?([A-Z][A-Za-z]+(?:Events|Info|Logs|Evidence|_CL)?)\b(?=\s*(\||$))') |
        ForEach-Object { $_.Groups[1].Value } | Sort-Object -Unique
    $old = $manual["$($r.id)"]

    [pscustomobject]@{
        RuleId            = "$($r.id)"
        DisplayName       = $r.displayName
        AlertTitle        = $tpl.title
        IsEnabled         = [bool]$r.isEnabled
        Period            = $r.schedule.period
        Severity          = $tpl.severity
        Category          = $tpl.category
        MitreTechniques   = ($tpl.mitreTechniques -join ';')
        Tables            = ($tables -join ';')
        ResponseActions   = (($r.detectionAction.responseActions | ForEach-Object { $_.'@odata.type' -replace '#microsoft.graph.security.', '' }) -join ';')
        LastRunStatus     = $r.lastRunDetails.status
        LastRunDateTime   = $r.lastRunDetails.lastRunDateTime
        CreatedBy         = $r.createdBy
        LastModified      = $r.lastModifiedDateTime
        AnalyticsRuleName = if ($old) { $old.AnalyticsRuleName } else { '' }
        ManualStatus      = if ($old) { $old.ManualStatus } else { '' }
        Notes             = if ($old) { $old.Notes } else { '' }
    }
}

$rows | Sort-Object DisplayName | Export-Csv -Path $Path -NoTypeInformation -Encoding UTF8
Write-Host "$($rows.Count) Custom Detections nach $Path exportiert."
